<script>
    function myFunction()
    {
        a=document.getElementsByName("my Text")[0]
        alert(a.value);
    }
</script>