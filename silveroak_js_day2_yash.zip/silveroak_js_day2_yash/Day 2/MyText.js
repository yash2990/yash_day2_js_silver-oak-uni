<script>
    function myFunction()
    {
        
        vartxt = document.getElementById("myText");
        alert(txt.value); 

    }
</script>